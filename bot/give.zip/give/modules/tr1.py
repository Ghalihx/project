from give import *

@bot.on(events.CallbackQuery(data=b'tr1'))
async def create_trojan(event):
    async def create_trojan_(event):
        user = "GiveVpnu" + str(random.randint(100, 1000))
        exp = "3"
        Quota = "1000"
        ip = "1"


        await event.edit("**Loading....**")
        cmd = f'printf "%s\n" "{user}" "{exp}" "{Quota}" "{ip}" | addtr-bot'
        try:
            a = subprocess.check_output(cmd, shell=True).decode("utf-8")
        except Exception as e:
            print(f'Error: {e}')
            print(f'Subprocess output: {a}')
            await event.respond(f"Terjadi kesalahan: {e}\nSubproses output: {a}")
            return  # Stop execution if there's an error

        today = DT.date.today()
        later = today + DT.timedelta(days=int(exp))
        b = [x.group() for x in re.finditer("trojan://(.*)", a)]
        print(b)
        domain = re.search("@(.*?):", b[0]).group(1)
        uuid = re.search("trojan://(.*?)@", b[0]).group(1)
        msg = f"""
**◇━━━━━━━━━━━━━━━━━◇**
       **⟨🔸Trojan Account🔸⟩**
**◇━━━━━━━━━━━━━━━━━◇**
**» Username :** `{user}`
**» Domain :** `{DOMAIN}`
**» Limit Quota :** `{Quota} GB`
**» Limit Login :** `{ip} HP`
**» HTTP   :** `80,8080,2086,8880`
**» TLS    :** `443,8443`
**» UUID    :** `{uuid}`
**» NetWork     :** `(WS) or (gRPC)`
**» Path        :** `/trojan-ws`
**» ServiceName :** `trojan-grpc`
**◇━━━━━━━━━━━━━━━━━◇**
**» URL TLS    :**
```{𝚋[0]}```
**◇━━━━━━━━━━━━━━━━━◇**
**» URL HTTP    :**
```{𝚋[1].𝚛𝚎𝚙𝚕𝚊𝚌𝚎(" ","")}```
**◇━━━━━━━━━━━━━━━━━◇**
**» URL gRPC   :** 
```{𝚋[2].𝚛𝚎𝚙𝚕𝚊𝚌𝚎(" ","")}```
**◇━━━━━━━━━━━━━━━━━◇**
**⟨Link Save Account⟩**
https://{DOMAIN}:81/trojan-{user}.txt
**◇━━━━━━━━━━━━━━━━━◇**
**» Expired Until:** `{later}`
**◇━━━━━━━━━━━━━━━━━◇**
**» ** 🌀@GallVpnStore
"""
        await event.respond(msg)

    chat = event.chat_id
    sender = await event.get_sender()
    a = valid(str(sender.id))  # Memanggil fungsi valid

    if a == "true":
        await create_trojan_(event)
    else:
        await event.answer("Buy Premium Chat: @GallVpnStore", alert=True)

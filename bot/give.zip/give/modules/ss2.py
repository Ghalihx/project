from give import *
import requests
import time
import subprocess
import datetime as DT
import re
import random
from telethon import events, Button

@bot.on(events.CallbackQuery(data=b'ss2'))
async def create_shadowsocks(event):
    user_id = str(event.sender_id)

    async def create_shadowsocks_(event):
        try:
            user = "GiveVpno" + str(random.randint(100, 1000))
            exp = "5"
            Quota = "1000"
            ip_limit = "1"
                 
            await event.edit("**Loading....**")  
            cmd = f'printf "%s\n" "{user}" "{exp}" "{Quota}" "{ip_limit}" | addss-bot'

            a = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT).decode("utf-8")

        except subprocess.CalledProcessError as e:
            print(f"Error executing command: {e}")
            print(f"Exit code: {e.returncode}")
            print(f"Output: {e.output.decode('utf-8')}")
            await event.respond(f"Error executing command: {e}")
            return  # Stop execution to prevent further processing on error

        except Exception as ex:
            print(f"Unexpected error: {ex}")
            await event.respond("An unexpected error occurred.")
            return  # Stop execution to prevent further processing on error

        today = DT.date.today()
        later = today + DT.timedelta(days=int(exp))
        x = [x.group() for x in re.finditer("ss://(.*)", a)]
        uuid = re.search("ss://(.*?)@", x[0]).group(1)

        msg = f"""
        
**◇━━━━━━━━━━━━━━━━━◇**
**⟨🔸SHDWSCSK Account🔸⟩**
**◇━━━━━━━━━━━━━━━━━◇**
**» Username :** `{user}`
**» Domain :** `{DOMAIN}`
**» Limit Quota :** `{Quota} GB`
**» Limit Login :** `{ip_limit} HP`
**» HTTP   :** `80,8080,2086,8880`
**» TLS    :** `443,8443`
**» UUID    :** `{uuid}`
**» NetWork     :** `(WS) or (gRPC)`
**» Path        :** `/ss-ws`
**» ServiceName :** `ss-grpc`
**◇━━━━━━━━━━━━━━━━━◇**
**» URL TLS    :**
```{x[0]}```
**◇━━━━━━━━━━━━━━━━━◇**
**» URL HTTP   :** 
```{x[1].replace(" ","")}```
**◇━━━━━━━━━━━━━━━━━◇**
**» URL gRPC   :** 
```{x[2].replace(" ","")}```
**◇━━━━━━━━━━━━━━━━━◇**
**⟨Link Save Account⟩**
https://{DOMAIN}:81/ss-{user}.txt
**◇━━━━━━━━━━━━━━━━━◇**
**» Expired Until:** `{later}`
**◇━━━━━━━━━━━━━━━━━◇**
»  🌀@GallVpnStore

        """

        await event.respond(msg)

    chat = event.chat_id
    sender = await event.get_sender()
    a = valid(str(sender.id))  # Memanggil fungsi valid

    if a == "true":
        await create_shadowsocks_(event)
    else:
        await event.answer("Buy Premium Chat: @GallVpnStore", alert=True)
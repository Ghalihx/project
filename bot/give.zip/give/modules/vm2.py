from give import *


@bot.on(events.CallbackQuery(data=b'vm2'))
async def create_vmess(event):
    async def create_vmess_(event):
        user = "GiveVpne" + str(random.randint(100, 1000))
        exp = "5"
        Quota = "1000"
        ip = "2"
    
        await event.edit("**Loading....**")
        cmd = f'printf "%s\n" "{user}" "{exp}" "{Quota}" "{ip}" | addws-bot'

        try:
            a = subprocess.check_output(cmd, shell=True).decode("utf-8")
        except Exception as e:
            print(f'Error: {e}')
            print(f'Subprocess output: {a}')
            await event.respond(f"An error occurred: {e}\nSubprocess output: {a}")
            return  # Stop execution if there's an error

        today = DT.date.today()
        later = today + DT.timedelta(days=int(exp))
        b = [x.group() for x in re.finditer("vmess://(.*)", a)]

        z = base64.b64decode(b[0].replace("vmess://", "")).decode("ascii")
        z = json.loads(z)

        z1 = base64.b64decode(b[1].replace("vmess://", "")).decode("ascii")
        z1 = json.loads(z1)

        msg = f"""
**◇━━━━━━━━━━━━━━━━━◇**
      **⟨🔸Vmess Account🔸⟩**
**◇━━━━━━━━━━━━━━━━━◇**
**» Username :** `{user}`
**» Domain :** `{DOMAIN}`
**» Limit Quota :** `{Quota} GB`
**» Limit Login :** `{ip} HP`
**» HTTP   :** `80,8080,2086,8880`
**» TLS    :** `443,8443`
**» UUID    :** `{z["id"]}`
**» Network     :** `(WS) or (gRPC)`
**» Path        :** `/vmess`
**» ServiceName :** `vmess-grpc`
**◇━━━━━━━━━━━━━━━━━◇**
**» URL TLS    :**
```{b[0].strip("'").replace(" ","")}```
**◇━━━━━━━━━━━━━━━━━◇**
**» URL HTTP    :**
```{b[1].strip("'").replace(" ","")}```
**◇━━━━━━━━━━━━━━━━━◇**
**» URL gRPC   :** 
```{b[2].strip("'")}```
**◇━━━━━━━━━━━━━━━━━◇**
**⟨Link Save Account⟩**
https://{DOMAIN}:81/vmess-{user}.txt
**◇━━━━━━━━━━━━━━━━━◇**
**» Expired Until:** `{later}`
**◇━━━━━━━━━━━━━━━━━◇**
**» ** 🌀@GallVpnStore


        """

        await event.respond(msg)

    chat = event.chat_id
    sender = await event.get_sender()
    a = valid(str(sender.id))  # Memanggil fungsi valid

    if a == "true":
        await create_vmess_(event)
    else:
        await event.answer("Buy Premium Chat: @GallVpnStore", alert=True)
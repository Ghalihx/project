from give import *
import subprocess
import json
import re
import base64
import datetime as DT
import requests
import time
import random
import asyncio
import tempfile
################

@bot.on(events.CallbackQuery(data=b'noobzvpns'))
async def vmess(event):
    async def vmess_(event):
        inline = [
            [Button.inline("𝟯 𝗗𝗮𝘆𝘀", "trial-noobz1"),
            Button.inline("𝟱 𝗗𝗮𝘆𝘀", "trial-noobz2")],
            [Button.inline("‹ 𝗠𝗮𝗶𝗻 𝗠𝗲𝗻𝘂 ›", "menu")]
        ]
        z = requests.get(f"http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
        msg = f"""
**◇━━━━━━━━━━━━━━━━━◇**
**◇⟨🔸NOOBZVPNS MENU🔸⟩◇**
**◇━━━━━━━━━━━━━━━━━◇**
**» Service:** `NOOBZVPNS`
**» Hostname/IP:** `{DOMAIN}`
**» ISP:** `{z["isp"]}`
**» Country:** `{z["country"]}`
**◇━━━━━━━━━━━━━━━━━◇**
**» ** 🌀@GallVpnStore
"""
        await event.edit(msg, buttons=inline)

    chat = event.chat_id
    sender = await event.get_sender()
    a = valid(str(sender.id))  # Memanggil fungsi valid

    if a == "true":
        await vmess_(event)
    else:
        await event.answer("Buy Premium Chat: @GallVpnStore", alert=True)



from give import *
import subprocess
import json
import re
import base64
import datetime as DT
import requests
import time
import random
import asyncio
import tempfile
################

@bot.on(events.CallbackQuery(data=b'trial-noobz1'))
async def trial_noobz(event):
    user_id = str(event.sender_id)
    async def trial_noobz_(event):
        user = "GiveVPNx" + str(random.randint(100, 1000))
        pw = "freenetlite1"
        exp = "3"
        ip = "1"
        Quota = "1000"
        
        
        await event.edit("**Loading....**")
        cmd = f'printf "%s\n" "{user}" "{pw}" "{exp}" "{Quota}" "{ip}" | addnoobz'
        try:
            subprocess.check_output(cmd, shell=True)
        except:
            await event.respond("**User Already Exist**")
        else:
            today = DT.date.today()
            later = today + DT.timedelta(days=int(exp))
            msg = f"""
**◇━━━━━━━━━━━━━━━━━◇**
** ⟨🔸Noobzvpn Account🔸⟩**
**◇━━━━━━━━━━━━━━━━━◇**
**» Host:** `{DOMAIN}`
**» Username:** `{user}`
**» Password:** `{pw}`
**» Limit Login:** `{ip} HP`
**» Limit Quota:** `{Quota} GB`
**◇━━━━━━━━━━━━━━━━━◇**
**» PORT:** `2082`
**» PORT:** `2083`
**◇━━━━━━━━━━━━━━━━━◇**
**⟨ Payload WS  ⟩**
```GET / HTTP/1.1[crlf]Host: [s_host][crlf]Upgrade: websocket[crlf]Connection: Upgrade[crlf]User-Agent: [ua][crlf][crlf]```
**◇━━━━━━━━━━━━━━━━━◇**
**» Expired Akun User:** `{exp}` Days
**◇━━━━━━━━━━━━━━━━━◇**
"""
            inline = [
                [Button.url("𝚃𝚎𝚕𝚎𝚐𝚛𝚊𝚖", "t.me/GallVpnStore"),
                 Button.url("𝚆𝚑𝚊𝚝𝚜𝚊𝚙𝚙", "wa.me/6283834366608")]
            ]
            await event.respond(msg, buttons=inline)

    chat = event.chat_id
    sender = await event.get_sender()
    a = valid(str(sender.id))  # Memanggil fungsi valid

    if a == "true":
        await trial_noobz_(event)
    else:
        await event.answer("Buy Premium Chat: @GallVpnStore", alert=True)

from cybervpn import *
import sqlite3
from telethon import events, Button
import datetime as DT
import random
import requests
import subprocess

# Inisialisasi database SQLite
conn = sqlite3.connect('trial_ssh.db')
cursor = conn.cursor()
cursor.execute("""
CREATE TABLE IF NOT EXISTS trial_logs (
    user_id TEXT PRIMARY KEY,
    last_trial_date DATE
)
""")
conn.commit()

@bot.on(events.CallbackQuery(data=b'trial-ssh-member'))
async def trial_ssh(event):
    user_id = str(event.sender_id)

    # Fungsi untuk melakukan trial SSH
    async def trial_ssh_(event):
        user = "Trial" + str(random.randint(100, 1000))
        pw = "freenetlite"
        ip = "1"
        Quota = "1"
        exp = "1"
        await event.edit("**Please Wait...**")
        cmd = f'printf "%s\n" "{user}" "{pw}" "{Quota}" "{ip}" "{exp}" | addssh-bot'
        try:
            subprocess.check_output(cmd, shell=True)
        except:
            await event.respond("**User Already Exist**")
        else:
            today = DT.date.today()
            later = today + DT.timedelta(days=int(exp))
            z = requests.get("http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
        try:
            with open('/etc/xray/dns', 'r') as file:
              NS = file.read().strip()
        except FileNotFoundError:
              NS = "Not found"

        try:
            with open('/etc/slowdns/server.pub', 'r') as file:
              PUB = file.read().strip()
        except FileNotFoundError:
              PUB = "Not found"
              
        msg = f"""
◇━━━━━━━━━━━━━━━━━◇
      **◇⟨SSH Account ⟩◇**
◇━━━━━━━━━━━━━━━━━◇
**» ISP:** `{z["isp"]}`
**» Location:** `{z["country"]}`
**» Host:** `{DOMAIN}`
**» Host SlowDNS:** `{NS}`
**» Username:** `{user}`
**» Password:** `{pw}`
**» Limit Quota :** `{Quota} GB`
**» Limit Login :** `{ip} HP`
◇━━━━━━━━━━━━━━━━━◇
**» Pub Key:** `{PUB}`
**» Port OpenSsh :** 22
**» Port Dropbear :** 143,109
**» Port Ssh Ws :** 80,8080,2086,8880
**» Port Ssh Ws/Tls :**443,8443
**» Port Ssh Ssl/Tls :**443
**» Port Ssh UDP :** 1-65535 
**» BadVPN UDP :** 7100,7300,7300
◇━━━━━━━━━━━━━━━━━◇
**⟨FORMAT HTTP CUSTOM⟩**
`{DOMAIN}:1-65535@{user}:{pw}`
◇━━━━━━━━━━━━━━━━━◇
**⟨Save Account⟩**
https://{DOMAIN}:81/ssh-{user}.txt
◇━━━━━━━━━━━━━━━━━◇
**⟨Payload Websocket⟩**
```GET /cdn-cgi/trace HTTP/1.1[crlf]Host: Bug_Kalian[crlf][crlf]GET-RAY / HTTP/1.1[crlf]Host: [host][crlf]Connection: Upgrade[crlf]User-Agent: [ua][crlf]Upgrade: websocket[crlf][crlf]```
◇━━━━━━━━━━━━━━━━━◇
**» Expired Until:** {today}
◇━━━━━━━━━━━━━━━━━◇
"""
            
        await event.respond(msg)

    chat = event.chat_id
    sender = await event.get_sender()

    # Validasi level pengguna
    try:
        level = get_level_from_db(user_id)
        print(f'Retrieved level from database: {level}')

        if level != 'user':
            await event.answer(f"Akses Ditolak...!!", alert=True)
            return

        # Periksa batas trial
        cursor.execute("SELECT last_trial_date FROM trial_logs WHERE user_id = ?", (user_id,))
        result = cursor.fetchone()
        today = DT.date.today()

        if result:
            last_trial_date = DT.datetime.strptime(result[0], "%Y-%m-%d").date()
            if last_trial_date == today:
                await event.respond("**Anda hanya dapat melakukan trial 1 kali dalam sehari. Coba lagi besok!**")
                return

        # Simpan log trial baru
        cursor.execute("REPLACE INTO trial_logs (user_id, last_trial_date) VALUES (?, ?)", (user_id, today))
        conn.commit()

        # Lanjutkan proses trial SSH
        await trial_ssh_(event)

    except Exception as e:
        print(f"Error: {e}")

import subprocess
from telethon import events, Button
from cybervpn import *  # Pastikan ini benar-benar modul yang Anda gunakan

@bot.on(events.CallbackQuery(data=b'renew-ssh-member'))
async def renew_ssh(event):
    user_id = str(event.sender_id)
    chat = event.chat_id
    sender = await event.get_sender()

    async def renew_ssh_():
        try:
            # Memulai percakapan untuk meminta data
            async with bot.conversation(chat) as conv:
                await conv.send_message("**Username :**")
                username_msg = await conv.get_response()
                username = username_msg.raw_text

                await conv.send_message("**Days :**")
                days_msg = await conv.get_response()
                days = "30"

                await conv.send_message("**Limit Quota :**")
                quota_msg = await conv.get_response()
                quota = "1000"

                await conv.send_message("**Limit IP :**")
                ip_limit_msg = await conv.get_response()
                ip_limit = "2"

            await process_user_balance_ssh(event, user_id)
            await event.edit("`Loading......`")
            cmd = f'printf "%s\\n" "{username}" "{days}" "{quota}" "{ip_limit}" | bot-renew-ssh'
            try:
                output = subprocess.check_output(cmd, shell=True).decode("utf-8")
                # Menampilkan hasil perintah
                await event.respond(f"""
**SUCCESSFULLY RENEWE SSH**
""", buttons=[[Button.inline("𝙼𝚊𝚒𝚗 𝙼𝚎𝚗𝚞", "menu")]])
            except subprocess.CalledProcessError as e:
                await event.respond(f"`Error:` {e.output.decode('utf-8')}")
            except Exception as e:
                await event.respond(f"`Error:` {str(e)}")
        except Exception as e:
            await event.respond(f"`Error:` {str(e)}")

    try:
        # Mengecek level pengguna
        level = get_level_from_db(user_id)
        print(f'Retrieved level from database: {level}')

        if level == 'user':
            await renew_ssh_()
        else:
            await event.answer(f"Akses Ditolak. Level Anda: {level}", alert=True)
    except Exception as e:
        print(f"Error: {e}")                